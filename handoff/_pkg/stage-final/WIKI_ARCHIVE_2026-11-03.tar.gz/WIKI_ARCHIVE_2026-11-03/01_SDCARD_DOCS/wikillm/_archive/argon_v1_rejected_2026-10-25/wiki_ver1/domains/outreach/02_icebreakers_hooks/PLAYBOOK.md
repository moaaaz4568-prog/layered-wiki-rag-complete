# PLAYBOOK — كاسرات الجليد والخطافات (Icebreakers & Hooks) (02_icebreakers_hooks)

> **حالة الملف:** قالب جاهز للتعبئة (Template) — مرحلة بناء الأنظمة فقط. ممنوع ملؤه بمحتوى معرفي قبل اكتمال استخراج مصطلحات المجال كاملاً (قاعدة المالك الحرفية: ممنوع ماستر قبل اكتمال مصطلحات مجاله).
> **طريقة التعبئة لاحقاً:** وكيل واحد يملأ حزمة 20-25 مفهوماً كحد أقصى (درس NB2: شريحة أكبر تقتل الوكيل)، يقرأ المصادر كاملة بلا فواقد (SYS_05)، ويملأ كل قسم وفق التعليمات الدقيقة داخله.
> **قواعد ثابتة:** عربية فصحى + مصطلح إنجليزي بين قوسين، صفر حرف صيني، ممنوع الحذف، كل رقم ومثال بمصدر path:line موجود فعلاً، فصل المبدأ عن المثال.

---

## §1: نظرة عامة على القسم (Section Overview)

**ماذا يُكتب هنا وبأي شروط:** تعريف القسم: ما المشكلة التي يحلها هذا القسم، ومتى يُستخدم، وعلاقته بالأقسام الأخرى في نفس الماستر. اكتب 3-6 أسطر فصحى، واذكر المصطلحات الإنجليزية بين قوسين مع شرح سيكولوجي موجز.

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §2: الحقائق النفسية (Psychological Truths)

**ماذا يُكتب هنا وبأي شروط:** اكتب الحقائق النفسية (Psychological Truths) الأساسية التي يقوم عليها هذا القسم: ما الذي يحدث في عقل الطرف الآخر؟ كل حقيقة يجب أن تكون مبدأً عاماً لا مثالاً شخصياً (قاعدة فصل المبدأ عن المثال — خطأ الآيس بريك محظور). المصدر: التفريغات في /sdcard/Nexus_Brain/Nexus_Brain/brain/ فقط، بلا تخمين.

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §3: المبادئ الاستراتيجية (Strategic Principles)

**ماذا يُكتب هنا وبأي شروط:** حوّل كل حقيقة نفسية في §2 إلى مبدأ استراتيجي قابل للتطبيق. الصيغة: «لأن [الحقيقة النفسية]، فإن [المبدأ]». ممنوع دمج مثال في المبدأ. كل مبدأ يوثق بمصدر path:line موجود فعلاً (تحقق بـ find قبل الكتابة).

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §4: التكتيكات (Tactics)

**ماذا يُكتب هنا وبأي شروط:** اسرد التكتيكات (Tactics) المتعددة لكل مبدأ في §3، كل تكتيك موسوم بالمبدأ الذي يخدمه وبمصدره الحرفي path:line. التكتيك هو التطبيق الشخصي — يجوز تعدده ولا يجوز رفعه لمبدأ. ممنوع حذف رأي أي خبير (قاعدة Zero Deletion)؛ رتّبها بلا حكم صح/خطأ.

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §5: الأمثلة الموثقة (Documented Examples)

**ماذا يُكتب هنا وبأي شروط:** أدرج أمثلة كاملة من المصادر الخام، كل مثال: (السياق، الفعل، النتيجة، المصدر path:line). كل مثال يبقى مثالاً موسوماً ولا يُرفع لقاعدة. المثال الوحيد المسموح في مرحلة البناء: مثال توضيحي واحد من مصدر حقيقي موجود على القرص.

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §6: مصفوفة تعددية الآراء (Pluralism Matrix)

**ماذا يُكتب هنا وبأي شروط:** إذا اختلف الخبراء في هذا القسم، اذكر كل رأي مع: صاحبه، مصدره، ومتى ينجح/يفشل (وفق SYS_08_PLURALISM_MATRIX). ممنوع الحكم بصحة/خطأ — فقط شروط التطبيق. إن لم يوجد اختلاف اكتب: «لم يوثق اختلاف في المصادر المتاحة».

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §7: حدود الفشل ومصفوفة الطوارئ (Failure Boundaries)

**ماذا يُكتب هنا وبأي شروط:** متى يفشل ما في هذا القسم؟ اربط بمصفوفة الطوارئ CONTINGENCY_MATRIX.md في نفس المجلد: كل حد فشل يرقم (C01، C02...) ويقابله إجراء بديل موثق. ممنوع كتابة حد فشل بلا بديل.

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §8: المصطلحات (Terms)

**ماذا يُكتب هنا وبأي شروط:** المصطلحات الجديدة التي أدخلها هذا القسم تُسجَّل في TERMS.md في نفس المجلد (التعريف بالعربية + المصطلح الإنجليزي + المصدر path:line). هذا القسم قائمة إحالة فقط لا تعريفات مكررة.

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §9: المصادر (Sources)

**ماذا يُكتب هنا وبأي شروط:** قائمة كل المصادر المستخدمة في هذا القسم بصيغة: SRC_<رقم> | المسار الكامل | رقم السطر/الأسطر. كل معرف SRC_ يشير لملف موجود فعلاً على القرص (تحقق بـ find). التفاصيل الكاملة في SOURCES_CATALOG.md في نفس المجلد.

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## §10: بوابة القبول (Acceptance Gate)

**ماذا يُكتب هنا وبأي شروط:** بوابة قابلة للقياس بأمر shell حرفي (على نمط GATES_11): مثال: grep -c '^### §' PLAYBOOK.md يجب أن يساوي 10، وكل مسار مصدر مذكور يُتحقق منه بـ find. البوابة حارسة لا حاجزة (درس V3) — تقيس ولا تعيق الإنتاج.

**مثال توضيحي (موسوم — لا يُرفع لقاعدة):** من /sdcard/Nexus_Brain/Nexus_Brain/brain/expandi__How to use Video Personalization on LinkedIn to get 2x more replies__7sJ-hBd4ZaQ.txt:1 — التخصيص الشخصي (Personalization) لرفع معدل الردود، وهو أساس كاسر الجليد.

---

## بوابة قبول الملف كاملاً (File Gate)

```bash
# 1) عشرة أقسام مكتملة:  grep -c '^## §' PLAYBOOK.md  ⇒ 10
# 2) صفر حرف صيني:  grep -rP '[\x{4e00}-\x{9fff}]' <مسار المجلد>/ | wc -l  ⇒ 0
# 3) كل مسار مصدر مذكور موجود:  find /sdcard/Nexus_Brain/Nexus_Brain/brain/ -name "<اسم الملف>" | wc -l  ⇒ ≥1
```
