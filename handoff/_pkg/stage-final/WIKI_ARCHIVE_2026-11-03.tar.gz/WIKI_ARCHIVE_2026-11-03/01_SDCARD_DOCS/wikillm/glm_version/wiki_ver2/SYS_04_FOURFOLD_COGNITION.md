# TOMBSTONE — SYS_04_FOURFOLD_COGNITION.md (مؤرشف)

> **هذا الملف لم يعد المرجع الحي.** النسخة الأصلية محفوظة حرفياً في
> `_archive/SYS_04_FOURFOLD_COGNITION.md` (نمط X4: أرشفة + tombstone — لا حذف).
>
> **المرجع الحي:** `systems/SYS_04_محرك_التفكير.md`
>
> سبب الاستبدال: نقل الأنظمة الخمسة إلى `systems/` بأسماء عربية وفق
> قرار البناء المعتمد في BUILD_PROTOCOL.md. أي تعديل مستقبلي يتم على
> المرجع الحي في `systems/` حصراً.
